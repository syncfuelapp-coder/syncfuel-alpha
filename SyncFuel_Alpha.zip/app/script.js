// Basic real-user app shell with localStorage persistence

let deferredPrompt;
const installBtn = document.getElementById('installBtn');
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  if (installBtn) installBtn.style.display = 'inline-block';
});
if (installBtn) {
  installBtn.addEventListener('click', async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    deferredPrompt = null;
    installBtn.style.display = 'none';
  });
}

// --- Hydration ---
const hydrationNowEl = document.getElementById('hydrationNow');
const hydrationGoalEl = document.getElementById('hydrationGoal');
const hydrationFillEl = document.getElementById('hydrationFill');

const state = JSON.parse(localStorage.getItem('syncfuel_state') || '{}');

function loadState() {
  const s = JSON.parse(localStorage.getItem('syncfuel_state') || '{}');
  if (!s.hydration) s.hydration = { now: 0.84, goal: 2.0 };
  if (!s.macros) s.macros = { p: {now:0, goal:250}, c: {now:0, goal:220}, f:{now:0, goal:50} };
  if (!s.meals) s.meals = [];
  localStorage.setItem('syncfuel_state', JSON.stringify(s));
  return s;
}
let S = loadState();

function renderHydration() {
  hydrationNowEl.textContent = S.hydration.now.toFixed(2);
  hydrationGoalEl.textContent = S.hydration.goal.toFixed(1);
  const pct = Math.min(100, Math.round((S.hydration.now / S.hydration.goal) * 100));
  hydrationFillEl.style.width = pct + '%';
}
function save() {
  localStorage.setItem('syncfuel_state', JSON.stringify(S));
}
document.querySelectorAll('[data-h2o]').forEach(btn => {
  btn.addEventListener('click', () => {
    const v = parseFloat(btn.getAttribute('data-h2o'));
    S.hydration.now = Math.max(0, +(S.hydration.now + v).toFixed(2));
    save(); renderHydration();
  });
});

// --- Macros ---
const pNow = document.getElementById('pNow');
const pGoal = document.getElementById('pGoal');
const cNow = document.getElementById('cNow');
const cGoal = document.getElementById('cGoal');
const fNow = document.getElementById('fNow');
const fGoal = document.getElementById('fGoal');

function renderMacros() {
  pNow.textContent = S.macros.p.now;
  pGoal.textContent = S.macros.p.goal;
  cNow.textContent = S.macros.c.now;
  cGoal.textContent = S.macros.c.goal;
  fNow.textContent = S.macros.f.now;
  fGoal.textContent = S.macros.f.goal;
}
document.querySelectorAll('[data-macro]').forEach(btn => {
  btn.addEventListener('click', () => {
    const k = btn.getAttribute('data-macro');
    const grams = parseInt(btn.getAttribute('data-grams'), 10);
    S.macros[k].now = Math.max(0, S.macros[k].now + grams);
    save(); renderMacros();
  });
});

// --- Meals ---
const mealList = document.getElementById('mealList');
const addMealBtn = document.getElementById('addMeal');

function renderMeals() {
  mealList.innerHTML = '';
  S.meals.forEach((m, idx) => {
    const li = document.createElement('li');
    li.innerHTML = `<span>${m.time} — ${m.name}</span><button data-del="${idx}" class="chip">Remove</button>`;
    mealList.appendChild(li);
  });
  mealList.querySelectorAll('[data-del]').forEach(btn => {
    btn.addEventListener('click', () => {
      const i = parseInt(btn.getAttribute('data-del'),10);
      S.meals.splice(i,1); save(); renderMeals();
    });
  });
}
if (addMealBtn) {
  addMealBtn.addEventListener('click', async () => {
    const name = prompt('Meal name (e.g., Chicken wrap)');
    if (!name) return;
    const now = new Date();
    const hh = String(now.getHours()).padStart(2,'0');
    const mm = String(now.getMinutes()).padStart(2,'0');
    S.meals.push({ name, time: `${hh}:${mm}` });
    save(); renderMeals();
  });
}

// --- Fuel Alert (placeholder logic) ---
const fuelAlertEl = document.getElementById('fuelAlert');
function computeFuelAlert() {
  // Placeholder: recommend fueling if protein < 40% of goal by afternoon or hydration < 50%
  const hour = new Date().getHours();
  const proteinPct = S.macros.p.now / S.macros.p.goal;
  const hydroPct = S.hydration.now / S.hydration.goal;
  if (hydroPct < 0.5) return 'Low hydration — drink 500 ml';
  if (hour >= 12 && proteinPct < 0.4) return 'Add ~40g protein in your next meal';
  return 'You’re on track — keep going';
}

// Initial render
function init() {
  S = loadState();
  renderHydration();
  renderMacros();
  renderMeals();
  fuelAlertEl.textContent = computeFuelAlert();
}
init();
